package modul6;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Pesanan {
    public int nomorMeja;
    public List<Menu> daftarItem;
    public Map<String, Integer> jumlahItem;
    public double totalHarga;

    public Pesanan(int nomorMeja) {
        this.nomorMeja = nomorMeja;
        this.daftarItem = new ArrayList<>();
        this.jumlahItem = new HashMap<>();
        this.totalHarga = 0;
    }

    public void tambahItem(Menu menu, int jumlah) {
        this.daftarItem.add(menu);
        this.jumlahItem.put(menu.nama, jumlah);
        hitungTotalHarga(); // Panggil method hitungTotalHarga setelah menambah item
    }

    public void tampilkanNota() {
        System.out.println("Nota Pemesanan");
        System.out.println("Nomor Meja: " + this.nomorMeja);
        for (Menu menu : daftarItem) {
            System.out.println(menu.nama + " x " + jumlahItem.get(menu.nama) + " = " + (menu.harga * jumlahItem.get(menu.nama)));
        }
        System.out.println("Total Harga: " + this.totalHarga);
    }
    
    public void hitungTotalHarga() {
        this.totalHarga = 0;
        for (Menu menu : this.daftarItem) {
            this.totalHarga += menu.harga * this.jumlahItem.get(menu.nama);
        }
    }


}