package modul6;

public class Main {
    public static void main(String[] args) {
        // Membuat objek menu
        Menu ayamGoreng = new Menu("Ayam Goreng", 25000, "Ayam goreng crispy", "Makanan Utama");
        Menu nasiPutih = new Menu("Nasi Putih", 5000, "Nasi putih pulen", "Makanan Pendamping");
        Menu esTehManis = new Menu("Es Teh Manis", 4000, "Es teh manis segar", "Minuman");

        // Membuat objek pesanan
        Pesanan pesanan = new Pesanan(1);
        pesanan.tambahItem(ayamGoreng, 2);
        pesanan.tambahItem(nasiPutih, 2);
        pesanan.tambahItem(esTehManis, 3);

        // Menampilkan nota
        pesanan.tampilkanNota();

        // Membuat objek pembayaran
        Pembayaran pembayaran = new Pembayaran(pesanan, "Tunai");
        pembayaran.prosesPembayaran(100000);

        // Mencetak struk
        pembayaran.cetakStruk();
    }
}
