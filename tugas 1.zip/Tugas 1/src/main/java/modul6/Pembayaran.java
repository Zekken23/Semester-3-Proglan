package modul6;

public class Pembayaran {
    public Pesanan pesanan;
    public String metodePembayaran;
    public double jumlahDibayarkan;
    public double kembalian;

    public Pembayaran(Pesanan pesanan, String metodePembayaran) {
        this.pesanan = pesanan;
        this.metodePembayaran = metodePembayaran;
    }

    public void prosesPembayaran(double jumlahDibayarkan) {
        this.jumlahDibayarkan = jumlahDibayarkan;
        this.kembalian = this.jumlahDibayarkan - this.pesanan.totalHarga;
    }

    public void cetakStruk() {
        System.out.println("Struk Pembayaran");
        this.pesanan.tampilkanNota();
        System.out.println("Metode Pembayaran: " + this.metodePembayaran);
        System.out.println("Jumlah Dibayarkan: " + this.jumlahDibayarkan);
        System.out.println("Kembalian: " + this.kembalian);
    }
}