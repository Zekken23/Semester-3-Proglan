package modul6;

public class Menu {
    public String nama;
    public double harga;
    public String deskripsi;
    public String kategori;

    public Menu(String nama, double harga, String deskripsi, String kategori) {
        this.nama = nama;
        this.harga = harga;
        this.deskripsi = deskripsi;
        this.kategori = kategori;
    }

    public void tampilkanDetailMenu() {
        System.out.println("Nama: " + this.nama);
        System.out.println("Harga: " + this.harga);
        System.out.println("Deskripsi: " + this.deskripsi);
        System.out.println("Kategori: " + this.kategori);
    }
}